from pathlib import Path
import os
import queue
import shutil
import sys
import tempfile
import threading
import zipfile
from datetime import datetime
import requests as req
import yaml
import tkinter as tk
from tkinter import messagebox, ttk

WORKSPACE = Path(__file__).resolve().parent
SERVER_URL = "http://127.0.0.1:5500"


class Updater:
    def __init__(self):
        try:
            current = self.read_version(WORKSPACE / "version.yaml")
            response = req.get(SERVER_URL + "/release_info.yaml", timeout=10)
            response.raise_for_status()
            newest = str(yaml.safe_load(response.text)["version"])
        except (OSError, req.RequestException, yaml.YAMLError, KeyError, TypeError) as exc:
            print(f"Update-Pruefung fehlgeschlagen: {exc}")
            return
        print(f"Installiert: {current}; Server: {newest}")
        if current == newest:
            return
        root = tk.Tk()
        root.withdraw()
        try:
            if not messagebox.askyesno("Update", f"Version {newest} installieren?", parent=root):
                return
            root.deiconify()
            root.title("Update installieren")
            root.geometry("450x130")
            root.resizable(False, False)
            root.protocol("WM_DELETE_WINDOW", lambda: None)
            ttk.Label(root, text="Update wird heruntergeladen und installiert ...").pack(pady=20)
            bar = ttk.Progressbar(root, mode="indeterminate")
            bar.pack(fill="x", padx=20)
            bar.start(15)
            result = queue.Queue()

            def worker():
                try:
                    self.install_release(newest)
                    result.put(None)
                except Exception as exc:
                    result.put(exc)

            def poll():
                try:
                    outcome = result.get_nowait()
                except queue.Empty:
                    root.after(100, poll)
                    return
                bar.stop()
                root.withdraw()
                if outcome is not None:
                    messagebox.showerror("Update fehlgeschlagen", str(outcome), parent=root)
                    root.quit()
                    return
                root.quit()
                self.restart_required = True

            self.restart_required = False
            threading.Thread(target=worker, daemon=True).start()
            root.after(100, poll)
            root.mainloop()
        finally:
            root.destroy()
        if getattr(self, "restart_required", False):
            # Replace the running interpreter so main.py is loaded from disk again.
            os.execv(sys.executable, [sys.executable, str(WORKSPACE / "main.py"), *sys.argv[1:]])

    @staticmethod
    def read_version(path):
        return str(yaml.safe_load(path.read_text(encoding="utf-8"))["version"])

    def install_release(self, version):
        # The repaired updater stays installed, even if a release includes an older one.
        with tempfile.TemporaryDirectory(prefix="myprogram-update-") as temp:
            stage = Path(temp)
            archive = stage / "release.zip"
            with req.get(SERVER_URL + f"/versions/{version}.zip", stream=True, timeout=(10, 60)) as response:
                response.raise_for_status()
                with archive.open("wb") as target:
                    for chunk in response.iter_content(64 * 1024):
                        target.write(chunk)
            extracted = stage / "files"
            extracted.mkdir()
            with zipfile.ZipFile(archive) as release:
                for entry in release.infolist():
                    target = (extracted / entry.filename).resolve()
                    if not target.is_relative_to(extracted.resolve()):
                        raise ValueError("Ungueltiger Pfad im Update-Archiv")
                release.extractall(extracted)
            if not (extracted / "main.py").is_file():
                raise ValueError("main.py fehlt im Update-Archiv")
            if self.read_version(extracted / "version.yaml") != version:
                raise ValueError("Versionsnummer im Archiv stimmt nicht mit dem Server ueberein")
            files = [p for p in extracted.rglob("*") if p.is_file()
                     and p.relative_to(extracted).parts[0] not in {"updater.py", "__pycache__", ".update-backups"}]
            # Write version.yaml last, only after all program files are installed.
            files.sort(key=lambda p: p.name == "version.yaml")
            backup = WORKSPACE / ".update-backups" / datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            backup.mkdir(parents=True)
            changed = []
            try:
                for source in files:
                    relative = source.relative_to(extracted)
                    target = WORKSPACE / relative
                    saved = backup / relative
                    existed = target.exists()
                    if existed:
                        saved.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(target, saved)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    changed.append((target, saved, existed))
                    shutil.copy2(source, target)
            except Exception:
                for target, saved, existed in reversed(changed):
                    if existed:
                        shutil.copy2(saved, target)
                    else:
                        target.unlink(missing_ok=True)
                raise
            print(f"Version {version} installiert. Sicherung: {backup}")


if __name__ == "__main__":
    Updater()
