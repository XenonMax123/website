from PIL import Image
from updater import Updater


class Main:
    def __init__(self):
        Updater()
    
    def create_image(self, width, height, color):
        image = Image.new("RGB", (width, height), color)
        return image
    
    def draw_circle(self, image, x, y, radius, color):
        from PIL import ImageDraw
        draw = ImageDraw.Draw(image)
        draw.ellipse((x - radius, y - radius, x + radius, y + radius), fill=color)
        return image

    def hue_noise(self, image, intensity):
        import numpy as np
        np_image = np.array(image.convert("HSV"))
        hue_noise = np.random.randint(-intensity, intensity + 1, np_image.shape[:2], dtype='int32')
        np_image[..., 0] = (np_image[..., 0].astype('int32') + hue_noise) % 256
        return Image.fromarray(np_image, "HSV").convert("RGB")
    
    def display_image(self, image):
        image.show()
    
if __name__ == "__main__":
    main_instance = Main()
    img = main_instance.create_image(200, 200, (255, 0, 255))
    img = main_instance.draw_circle(img, 100, 100, 50, (170, 255, 0))
    img = main_instance.hue_noise(img, 20)
    main_instance.display_image(img)